var rp = require('request-promise');
var Promise = require('bluebird');
var request = require('sync-request');
var AWSXRay = require('aws-xray-sdk');
var AWS = AWSXRay.captureAWS(require('aws-sdk'));
AWS.config.update({region: 'eu-west-1'});
var ARTIFACTORY_BASE_URL = "https://artifactory.portbase.io/artifactory";

let auth;
const encrypted = process.env['AUTH'];

var query_snapshot_directories = 'items.find({"repo":{"\$eq":"libs-snapshot-local"},"created":{"$before":"4w"},"type":{"\$eq":"folder"}})';
var query_release_directories  = 'items.find({"repo":{"\$eq":"libs-release-local" },"path":{"$match":"com/portbase/wpcs/*"}, "created":{"$before":"2w"},"type":{"\$eq":"folder"}})';
var query_old_snapshots        = 'items.find({"repo":{"$eq":"libs-snapshot-local"},"created":{"$before":"3w"}, "type":{"$eq":"file"}, "name":{"$ne":"maven-metadata.xml"} } )';
var query_old_wpcs_stuff       = 'items.find({"repo":{"$eq":"libs-release-local"}, "path":{"$match":"com/portbase/wpcs/*"}, "created":{"$before":"1w"}, "type":{"$eq":"file"}, "name":{"$ne":"maven-metadata.xml"}})';

exports.handler = (event, context, callback) => {
    AWSXRay.captureHTTPsGlobal(require('https'));
    AWSXRay.capturePromise();
    if (auth) {
        processEvent(event, context, callback);
    } else {
        // Decrypt code should run once and variables stored outside of the function
        // handler so that these are decrypted once per container
        const kms = new AWS.KMS();
        kms.decrypt({ CiphertextBlob: new Buffer(encrypted, 'base64') }, (err, data) => {
            if (err) {
                console.log('Decrypt error:', err);
                return callback(err);
            }
            auth = 'Basic '+ data.Plaintext.toString('ascii');
            processEvent(event, context, callback);
        });
    }
};

function processEvent(event, context, callback) {

  console.log('requesting older artefacts');
  var artefacts = [];
  artefacts = find(query_old_snapshots).concat(find(query_old_wpcs_stuff));
  console.log('old artefacts #:' + artefacts.length);

  deleteArtefacts(artefacts)
    .then( function() {
      console.log('deleting empty directories');
      deleteEmptyDirectories( find(query_release_directories) );
      deleteEmptyDirectories( find(query_snapshot_directories) );
  });

}


function find(query) {
  var res = request('POST', ARTIFACTORY_BASE_URL + '/api/search/aql', { headers: { 'Authorization': auth }, body: query });
  var results = JSON.parse(res.getBody('UTF-8')).results;
  var artefacts = [];
  var i;
  for (i = 0; i < results.length; i++) {
    var result = results[i];
    artefacts.push(result.repo + '/' + result.path + '/' + result.name);
  }
  return artefacts;
}


function deleteEmptyDirectories(directories) {
  console.log('candidate folders #:' +  directories.length);
  checkEmpty(directories)
    .then( (folders) => {
      var emptyFolders = [];
      var i;
      for (i = 0; i < folders.length; i++) {
         var folder = folders[i];
         if (folder !== '') {
           emptyFolders.push(folder);
         }
      }
      deleteArtefacts(emptyFolders);
    })
    .catch( (err) => {
      console.log('oops: ' + err);
    });
}

function checkEmpty(folders) {
  return Promise.map(folders, function (folder) {    
    var options = {        
      uri: ARTIFACTORY_BASE_URL + '/api/storage/' + folder,
      json: true,        
      timeout: 90000,        
      headers: { 'Authorization': auth }
    };
    return rp(options).then(function (body) {
        if (body.children.length === 0) {
          console.log('candidate OK' +  folder);
          return folder;
        } else {
          return '';
        }
    }); 
   }, 
   { concurrency:20});
}


function deleteArtefacts(entries) {
  return Promise.map(entries, function (entry) {
    var options = {
      method: 'DELETE',
      uri: ARTIFACTORY_BASE_URL + '/' + entry,
      timeout: 90000,
      headers: { 'Authorization': auth }
    };
    return rp(options)
      .then( function() { console.log('deleted=' + entry); } );
   },
   { concurrency:10});
}
