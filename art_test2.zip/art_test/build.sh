#!/bin/sh
set -e

cd /project

rm -rf build

npm install
npm run package

chmod -R 777 build/*.zip
